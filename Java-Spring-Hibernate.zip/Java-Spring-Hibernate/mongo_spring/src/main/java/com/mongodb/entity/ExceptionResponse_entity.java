//package com.mongodb.entity;
//
//
////	EXCEPTION ENTITY CLASS (TO BE INCLUDED INSIDE ENTITY PACKAGE)
//public class ExceptionResponse_entity {
//
//	private String error;
//
//	public ExceptionResponse_entity() {
//		// TODO Auto-generated constructor stub
//	}
//
//	public ExceptionResponse_entity(String error) {
//		super();
//		this.error = error;
//	}
//
//	public String getError() {
//		return error;
//	}
//
//	public void setError(String error) {
//		this.error = error;
//	}
//
//
//}
