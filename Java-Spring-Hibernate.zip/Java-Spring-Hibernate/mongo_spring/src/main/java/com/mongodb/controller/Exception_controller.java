//package com.mongodb.controller;
//
////	The purpose of this class is to stop Java's default "ResponseEntityExceptionHandler" from intercepting the custom exception declared
//import org.springframework.http.HttpStatus;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.ResponseStatus;
//
//import com.mongodb.entity.ExceptionResponse_entity;
//import com.mongodb.exception.Product_exception;
//
//@ControllerAdvice
//public class Exception_controller {
//
//	@ExceptionHandler(Product_exception.class)
//	@ResponseBody
//	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//	public ExceptionResponse_entity handleExceptionResponse(Product_exception pe) {
//		ExceptionResponse_entity response = new ExceptionResponse_entity(pe.getMessage());
//		return response;
//	}
//}
// 	