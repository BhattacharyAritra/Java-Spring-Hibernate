package com.mongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.mongodb.entity.CRUDControllerException;
import com.mongodb.entity.Product;
import com.mongodb.service.Product_serv;

@RestController
@RequestMapping("/product")
public class Product_contr {

	@Autowired
	private Product_serv service;

	@SuppressWarnings("unchecked")
	@GetMapping("")
	public List<Product> list(){
		try {
			return service.listProduct();
		} catch (Exception e) {
			// TODO: handle exception
			return (List<Product>) new ResponseEntity<ExceptionHandlingController>(HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping("/{id}")
	public ResponseEntity<?> update(@RequestBody Product prod, @PathVariable Long id){
		try {
			Product inProd = service.getProduct(id);
			inProd.setId(id);
			service.savProduct(inProd);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			//			CRUDControllerException ce = new CRUDControllerException("600", "Something went wrong!! Please check controller.");
			return new ResponseEntity<ExceptionHandlingController>(HttpStatus.BAD_REQUEST);
			//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/")
	public ResponseEntity<?> create (@RequestBody Product prod, @RequestParam String passcode) {
		try {
			service.savProduct(prod);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			//			CRUDControllerException ce = new CRUDControllerException("600", "Something went wrong!! Please check controller.");
			return new ResponseEntity<ExceptionHandlingController>(HttpStatus.BAD_REQUEST);
			//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/{id}")
	public void remove (@PathVariable Long id) {
		service.deleteProduct(id);
	}
}
