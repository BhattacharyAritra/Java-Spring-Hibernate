//package com.mongodb.exception;
//
////	CUSTOM EXCEPTION CLASS (SEPARATE EXCPETION PACKAGE TO BE CREATED)
//public class Product_exception extends RuntimeException{
//
//	/**
//	 * 
//	 */
//	private static final long serialVersionUID = 1L;
//	private String exceptionMessage;
//
//	public Product_exception() {
//	}
//
//	public Product_exception(String exceptionMessage) {
//		super();
//		this.exceptionMessage = exceptionMessage;
//	}
//
//	public String getExceptionMessage() {
//		return exceptionMessage;
//	}
//
//	public void setExceptionMessage(String exceptionMessage) {
//		this.exceptionMessage = exceptionMessage;
//	}
//
//
//}
