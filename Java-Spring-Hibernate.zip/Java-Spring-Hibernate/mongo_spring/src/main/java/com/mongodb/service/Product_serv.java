package com.mongodb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongodb.entity.Product;
import com.mongodb.repository.Product_repo;

@Service
public class Product_serv {

	@Autowired
	private Product_repo repository;
	
	public Product getProduct(Long id) {
		return repository.findById(id).get();
	}
	
	public void deleteProduct(Long id) {
		repository.deleteById(id);
	}
	
	public void savProduct(Product prod) {
		repository.insert(prod);
	}
	
	public List<Product> listProduct(){
		return repository.findAll();
	}
}
