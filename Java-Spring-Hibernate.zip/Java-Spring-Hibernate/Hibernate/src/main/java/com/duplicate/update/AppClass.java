package com.duplicate.update;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.hibernate.duplicate.EmployeeStructure;

public class AppClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration con = new Configuration().configure().addAnnotatedClass(EmployeeStructure.class);
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction trn = session.beginTransaction();

		EmployeeStructure emp1 = session.load(EmployeeStructure.class, 15);
		emp1.setEname("XYZ");
		session.update(emp1);
		
		
		trn.getStatus();		
		trn.commit();

	}

}
