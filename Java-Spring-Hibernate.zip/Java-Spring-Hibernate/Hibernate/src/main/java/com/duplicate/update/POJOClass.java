package com.duplicate.update;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class POJOClass {

	@Id
	@Column(name = "eid")
	private int eid;
	@Column(name = "ename")
	private String ename;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public POJOClass(int eid, String ename) {
		super();
		this.eid = eid;
		this.ename = ename;
	}
	public POJOClass() {
		super();
		// TODO Auto-generated constructor stub
	}
		
}
