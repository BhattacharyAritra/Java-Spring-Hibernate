package com.demo.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class EmployeePOJO {

	@Id
	@Column(name = "eid")
	private int eid;
	@Column(name = "ename")
	private String ename;
	
	public EmployeePOJO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeePOJO(int eid, String ename) {
		super();
		this.eid = eid;
		this.ename = ename;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
//	@Override
//	public String toString() {
//		return "EmployeePOJO [eid=" + eid + ", ename=" + ename + "]";
//	}
}
