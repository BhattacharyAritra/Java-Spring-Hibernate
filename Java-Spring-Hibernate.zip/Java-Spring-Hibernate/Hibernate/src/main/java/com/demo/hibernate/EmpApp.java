package com.demo.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class EmpApp {

	public static void main(String[] args) {
		
		Configuration con = new Configuration().configure().addAnnotatedClass(EmployeePOJO.class);
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		
		SessionFactory sf = con.buildSessionFactory(reg);
		
		Session session = sf.openSession();
		
		Transaction trn = session.beginTransaction();
		
		EmployeePOJO emp = new EmployeePOJO(10, "ABC");
//		EmployeePOJO emp1 = new EmployeePOJO(1, "DEF");
		session.save(emp);
//		session.save(emp1);
		
		trn.getStatus();		
		trn.commit();
	}

	
	
}
