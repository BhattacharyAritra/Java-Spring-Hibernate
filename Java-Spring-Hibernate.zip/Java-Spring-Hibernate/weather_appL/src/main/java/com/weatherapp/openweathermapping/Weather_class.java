package com.weatherapp.openweathermapping;

import com.weatherapp.openweathermapping.interface_implement.Weather_interface;

import net.aksingh.owmjapis.api.APIException;
import net.aksingh.owmjapis.core.OWM;
import net.aksingh.owmjapis.core.OWM.Country;
import net.aksingh.owmjapis.model.CurrentWeather;
import net.aksingh.owmjapis.model.DailyWeatherForecast;

public class Weather_class implements Weather_interface{

	private OWM_class owm_class = new OWM_class();

	@Override
	public CurrentWeather weatherByCityName(String city_name) throws APIException {
		// TODO Auto-generated method stub
		return owm_class.create().currentWeatherByCityName(city_name);
	}

	//	CurrentWeather object which consists basic information about weather.
	@Override
	public CurrentWeather weatherByCityNameandCountryCode(String city_name, Country country_code) throws APIException {
		// TODO Auto-generated method stub
		return owm_class.create().currentWeatherByCityName(city_name, country_code);
	}

	@Override
	public DailyWeatherForecast fiveDaysForecastByCityName(String city_name, int numberOfDays) throws APIException {
		// TODO Auto-generated method stub
		return owm_class.create().dailyWeatherForecastByCityName(city_name, numberOfDays);
	}

	//	DailyWeatherForecast object which consists basic information about weather forecast for number of days.
	@Override
	public DailyWeatherForecast fiveDaysForecastByCityNameandCountryCode(String city_name, int numberOfDays, OWM.Country country_code) throws APIException {
		// TODO Auto-generated method stub
		return owm_class.create().dailyWeatherForecastByCityName(city_name, country_code, numberOfDays);
	}

}
