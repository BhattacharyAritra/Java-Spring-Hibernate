package com.weatherapp.openweathermapping;

import com.weatherapp.configuration.api_configuration;
import com.weatherapp.openweathermapping.interface_implement.OWM_interface;

import net.aksingh.owmjapis.core.OWM;

public class OWM_class implements OWM_interface{

	@Override
	public OWM create() {
		// TODO Auto-generated method stub
		return new OWM(api_configuration.getApiKey());
	}

	@Override
	public OWM create(String api_key) {
		// TODO Auto-generated method stub
		return new OWM(api_key);
	}

}
