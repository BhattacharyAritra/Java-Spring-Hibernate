package com.weatherapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherAppLApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherAppLApplication.class, args);
	}

}
