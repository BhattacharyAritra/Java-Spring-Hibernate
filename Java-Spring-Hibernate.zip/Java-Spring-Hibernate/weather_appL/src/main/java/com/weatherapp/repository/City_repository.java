package com.weatherapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.weatherapp.entity.City;

@Repository
public interface City_repository extends JpaRepository<City, Integer>{

}
