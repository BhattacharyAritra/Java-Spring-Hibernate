package com.weatherapp.openweathermapping.interface_implement;

import net.aksingh.owmjapis.core.OWM;

public interface OWM_interface {

	//	Interface prototype for object creation of OWM object
	OWM create();

	//	Interface prototype for object creation of API key 
	OWM create(String api_key);
}
