package com.weatherapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.weatherapp.service.city_interface.City_service;

@Controller
public class Index_controller {

	private City_service city_service;

	@Autowired
	public void setCityService(City_service city_service) {
		this.city_service = city_service;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Model model) {
		model.addAttribute("cities", city_service.listAllCities());
		return "index";
	}
}
