package com.weatherapp.openweathermapping.interface_implement;

import net.aksingh.owmjapis.api.APIException;
import net.aksingh.owmjapis.core.OWM;
import net.aksingh.owmjapis.model.CurrentWeather;
import net.aksingh.owmjapis.model.DailyWeatherForecast;

public interface Weather_interface{

	//	 This method is returning object with information about current weather in city served as parameter.
	CurrentWeather weatherByCityName (String city_name) throws APIException;

	//	This method is returning object with information about current weather in city in specified country.
	CurrentWeather weatherByCityNameandCountryCode (String city_name, OWM.Country country_code) throws APIException;

	//	This method is returning object with information about 5 or whatever day weather forecast in city served as parameter.
	DailyWeatherForecast fiveDaysForecastByCityName (String city_name, int numberOfDays) throws APIException;

	//	This method is returning object with information about 5 or whatever day weather forecast in city in certain country served as parameters.
	DailyWeatherForecast fiveDaysForecastByCityNameandCountryCode (String city_name, int numberOfDays , OWM.Country country_code) throws APIException;
}
