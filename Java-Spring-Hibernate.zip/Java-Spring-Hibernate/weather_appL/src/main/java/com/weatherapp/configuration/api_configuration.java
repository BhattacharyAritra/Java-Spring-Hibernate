package com.weatherapp.configuration;

public class api_configuration {

	static private String openWeatherMapKey = "e685b9460e1ea1a40d27d353b3503c33";
	
	public static String getApiKey() {
		return openWeatherMapKey;
	}
}
	