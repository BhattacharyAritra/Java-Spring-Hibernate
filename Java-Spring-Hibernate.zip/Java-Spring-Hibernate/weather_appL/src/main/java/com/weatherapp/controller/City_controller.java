package com.weatherapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.weatherapp.entity.City;
import com.weatherapp.service.city_interface.City_service;

@Controller
public class City_controller {

	private City_service city_service;

	@Autowired
	public void setCityService(City_service city_service) {
		this.city_service = city_service;
	}

	@RequestMapping(value = "/cities", method = RequestMethod.GET)
	public String listCity(Model model) {
		model.addAttribute("cities", city_service.listAllCities());
		System.out.println("Returning cities:");
		return "cities";
	}

	@RequestMapping("/city/{id}")
	public String showCity(@PathVariable Integer id, Model model) {
		model.addAttribute("city", city_service.getCityById(id));
		City myCity = new City();
		myCity = city_service.getCityById(id);
		System.out.println(myCity.getCityName());
		return "cityshow";
	}

	@RequestMapping("/city/edit/{id}")
	public String editCity(@PathVariable Integer id, Model model) {
		model.addAttribute("city", city_service.getCityById(id));
		return "cityform";
	}

	@RequestMapping("city/new")
	public String newCity(Model model) {
		model.addAttribute("city", new City());
		return "cityform";
	}

	@RequestMapping(value = "city", method = RequestMethod.POST)
	public String saveCity(City city) {
		city_service.saveCity(city);
		return "redirect:/city/" + city.getId();
	}

	@RequestMapping("city/delete/{city_id}")
	public String delete(@PathVariable Integer id) {
		city_service.deleteCity(id);
		return "redirect:/cities";
	}
}
