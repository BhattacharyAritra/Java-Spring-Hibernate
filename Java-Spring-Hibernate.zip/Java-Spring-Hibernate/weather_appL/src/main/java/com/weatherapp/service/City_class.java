package com.weatherapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.weatherapp.entity.City;
import com.weatherapp.repository.City_repository;
import com.weatherapp.service.city_interface.City_service;

@Service
public class City_class implements City_service{

	private City_repository city_repo;

	@Autowired
	public void setCityRepository(City_repository city_repo) {
		this.city_repo = city_repo;
	}


	@Override
	public Iterable<City> listAllCities() {
		// TODO Auto-generated method stub
		return city_repo.findAll();
	}

	@Override
	public City getCityById(Integer id) {
		// TODO Auto-generated method stub
		return city_repo.getById(id);
	}

	@Override
	public City saveCity(City city) {
		// TODO Auto-generated method stub
		return city_repo.save(city);
	}

	@Override
	public void deleteCity(Integer id) {
		// TODO Auto-generated method stub
		city_repo.deleteById(id);

	}
}

