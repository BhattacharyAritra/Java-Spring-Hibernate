package com.weatherapp.service.city_interface;

import com.weatherapp.entity.City;

public interface City_service {

	Iterable<City> listAllCities();
	City getCityById(Integer id);
	City saveCity(City city);
	void deleteCity(Integer id);
}
