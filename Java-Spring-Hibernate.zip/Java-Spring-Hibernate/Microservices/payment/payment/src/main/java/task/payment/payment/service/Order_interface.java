package task.payment.payment.service;

import task.payment.payment.entity.Order;

public interface Order_interface {

	public Order getOrder(Long id);
}
