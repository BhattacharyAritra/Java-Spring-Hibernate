package task.payment.payment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import task.payment.payment.entity.Order;
import task.payment.payment.service.Order_interface;

@RestController
@RequestMapping("/order")
public class Order_controller {

	@Autowired
	private Order_interface orderint;
	
	@Autowired
	private RestTemplate template;
	
	@GetMapping("/{order_id}")
	public Order getOrder(@PathVariable("order_id") Long id) {
		
		Order order = this.orderint.getOrder(id);
		List payment = this.template.getForObject("http://localhost:9004/payment/order"+id, List.class);
		order.setPayment(payment);
		return order;
		
	}
	
	
}
