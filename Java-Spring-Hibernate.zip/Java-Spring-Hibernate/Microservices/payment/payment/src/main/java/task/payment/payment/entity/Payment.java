package task.payment.payment.entity;

public class Payment {

	private Long id;
	private Long paymentid;
	private String transactionstatus;
	private String bankname;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPaymentid() {
		return paymentid;
	}
	public void setPaymentid(Long paymentid) {
		this.paymentid = paymentid;
	}
	public String getTransactionstatus() {
		return transactionstatus;
	}
	public void setTransactionstatus(String transactionstatus) {
		this.transactionstatus = transactionstatus;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public Payment(Long id, Long paymentid, String transactionstatus, String bankname) {
		super();
		this.id = id;
		this.paymentid = paymentid;
		this.transactionstatus = transactionstatus;
		this.bankname = bankname;
	}
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

}
