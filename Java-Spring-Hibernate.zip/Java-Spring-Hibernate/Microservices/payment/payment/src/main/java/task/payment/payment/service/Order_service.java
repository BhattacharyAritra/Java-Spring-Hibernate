package task.payment.payment.service;

import java.util.List;

import org.springframework.stereotype.Service;

import task.payment.payment.entity.Order;


@Service
public class Order_service implements Order_interface {

	List<Order> order = List.of(
			new Order(100L, "Trees", "Kerala"),
			new Order(200L, "Clouds", "Kerala"),
			new Order(300L, "Soil", "Kerala"),
			new Order(400L, "Water", "Kerala"),
			new Order(500L, "Light", "Kerala")
			);

	@Override
	public Order getOrder(Long id) {
		// TODO Auto-generated method stub
		return this.order.stream().filter(i -> i.getId().equals(id)).findAny().orElse(null);
	}

}
