package task.payment.payment.entity;

import java.util.ArrayList;
import java.util.List;

public class Order {

	private Long id;
	private String name;
	private String location;
	List<Payment> payment = new ArrayList<>();
	
	public List<Payment> getPayment() {
		return payment;
	}
	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(Long id, String name, String location) {
		super();
//		this.payment = payment;
		this.id = id;
		this.name = name;
		this.location = location;
	}

}
