package task.order.order.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import task.order.order.entity.Payment;

@Service
public class Payment_service implements Payment_interface{

	List<Payment> list = List.of(
			new Payment(100L, 10L, "Paid", "HDFC"),
			new Payment(200L, 20L, "Paid", "ABN-Amro"),
			new Payment(300L, 30L, "Paid", "ICICI"),
			new Payment(400L, 40L, "Paid", "SBI"),
			new Payment(500L, 50L, "Paid", "Federal")
			);
	
	@Override
	public List<Payment> getPayments(Long id) {
		// TODO Auto-generated method stub
		return list.stream().filter(i -> i.getId().equals(id)).collect(Collectors.toList());
	}

}
