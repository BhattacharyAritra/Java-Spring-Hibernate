package task.order.order.service;

import java.util.List;

import task.order.order.entity.Payment;

public interface Payment_interface {

	public List<Payment> getPayments(Long id);
}
