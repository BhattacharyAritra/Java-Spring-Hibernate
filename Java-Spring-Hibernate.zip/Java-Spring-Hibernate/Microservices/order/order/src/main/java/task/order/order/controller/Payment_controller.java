package task.order.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import task.order.order.entity.Payment;
import task.order.order.service.Payment_interface;

@RestController
@RequestMapping("/payment")
public class Payment_controller {

	@Autowired
	private Payment_interface paymentint;
	
	@RequestMapping("/order/{order_id}")
	public List<Payment> getPayments(@PathVariable("order_id") Long id){
		return this.paymentint.getPayments(id);
	}
}
