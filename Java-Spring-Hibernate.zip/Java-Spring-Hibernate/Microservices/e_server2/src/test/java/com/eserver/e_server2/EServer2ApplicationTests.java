package com.eserver.e_server2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EServer2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
