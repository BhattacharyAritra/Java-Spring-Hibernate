package com.weather_forecast.model.weather;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;



import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.weather_forecast.model.Date_model;
import com.weather_forecast.model.Time_model;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"date",	"time"})
public class ForecastWeather_model {

	private Time_model time;
	public Time_model getTime() {
		return time;
	}

	public void setTime(Time_model time) {
		this.time = time;
	}

	@JsonProperty("date")
	private String date;
	@JsonIgnore
	private Serializable additionalProperties = new HashMap<String, Object>();

	@JsonProperty("date")
	public String getdate() {
		return date;
	}

	@JsonProperty("date")
	public void setdate(String date) {
		this.date= date;
	}

	@SuppressWarnings("unchecked")
	@JsonAnyGetter
	public Map<Date_model ,Time_model> getAdditionalProperties() {
		return (Map<Date_model, Time_model>) this.additionalProperties;
	}

	@SuppressWarnings("unchecked")
	@JsonAnySetter
	public void setAdditionalProperty(  Object date, Object time ) {
		((HashMap<Object,Object>) this.additionalProperties).put(date,time);
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(getdate() );
		return buffer.toString();
	}

}