package com.weather_forecast.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.weather_forecast.model.weather.Example_model;
import com.weather_forecast.service.Weather_service;

@RestController
public class Weather_controller {

	private Weather_service weatherService;

	@Autowired
	public Weather_controller (Weather_service weatherService) {
		this.weatherService = weatherService;
	}

	@RequestMapping("/")
	String home() {
		return "Hello World! Edit in URL bar for current weather and weather forecast city wise.";
	}

	@RequestMapping("forecast/{city}")
	public List<Example_model> getWeatherForFive(@PathVariable String city) throws ParseException {
		return this.weatherService.getWeatherForFive(city);		
	}	

	@RequestMapping("weather/{city}")
	public List<Example_model> getWeather(@PathVariable String city) throws ParseException{
		return this.weatherService.getWeather(city);		
	}

}
