package com.weather_forecast.model.weather;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"forecast_weather",	"todays_weather"})
public class Example_model {

	@JsonProperty("forecast_weather")
	private ForecastWeather_model forecastWeather;
	@JsonProperty("todays_weather")
	private TodaysWeather_model todaysWeather;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("forecast_weather")
	public ForecastWeather_model getForecastWeather() {
		return forecastWeather;
	}

	@JsonProperty("forecast_weather")
	public void setForecastWeather(ForecastWeather_model forecastWeather) {
		this.forecastWeather = forecastWeather;
	}

	@JsonProperty("todays_weather")
	public TodaysWeather_model getTodaysWeather() {
		return todaysWeather;
	}

	@JsonProperty("todays_weather")
	public void setTodaysWeather(TodaysWeather_model todaysWeather) {
		this.todaysWeather = todaysWeather;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
