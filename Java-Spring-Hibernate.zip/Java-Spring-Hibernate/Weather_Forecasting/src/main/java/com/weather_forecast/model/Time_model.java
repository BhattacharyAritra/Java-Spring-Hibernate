package com.weather_forecast.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.weather_forecast.model.weather.Weather_model;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"time",	"main",	"weather"})
public class Time_model {

	private String time;
	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@JsonProperty("main")
	private Main_model main;
	@JsonProperty("weather")
	private Weather_model weather;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("main")
	public Main_model getMain() {
		return main;
	}

	@JsonProperty("main")
	public void setMain(Main_model main) {
		this.main = main;
	}

	@JsonProperty("weather")
	public Weather_model getWeather() {
		return weather;
	}

	@JsonProperty("weather")
	public void setWeather(Weather_model weather) {
		this.weather = weather;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}